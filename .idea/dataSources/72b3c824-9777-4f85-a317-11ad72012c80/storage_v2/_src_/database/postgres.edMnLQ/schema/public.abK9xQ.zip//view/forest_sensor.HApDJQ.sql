create view forest_sensor(forest_no, name, sensor_id) as
SELECT f.forest_no,
       f.name,
       s.sensor_id
FROM forest f,
     sensor s,
     forest
         JOIN sensor ON sensor.x >= forest.mbr_xmin AND sensor.x <= forest.mbr_xmax AND sensor.y >= forest.mbr_ymin AND
                        sensor.y <= forest.mbr_ymax
GROUP BY f.name, f.forest_no, s.sensor_id
ORDER BY f.forest_no;

alter table forest_sensor
    owner to postgres;

