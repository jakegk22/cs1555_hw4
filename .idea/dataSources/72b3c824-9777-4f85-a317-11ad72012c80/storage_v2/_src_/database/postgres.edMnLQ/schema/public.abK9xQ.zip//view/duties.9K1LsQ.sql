create view duties(maintainer, total_num_of_sensors_per_maintainer) as
SELECT s.maintainer,
       count(s.maintainer) AS total_num_of_sensors_per_maintainer
FROM worker w,
     sensor s
WHERE s.maintainer::text = w.ssn::text
GROUP BY s.maintainer;

alter table duties
    owner to postgres;

