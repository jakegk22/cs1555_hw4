create view forest_road(forest_no, name, num_of_roads) as
SELECT f.forest_no,
       f.name,
       count(i.road_no) AS num_of_roads
FROM intersection i,
     forest f
WHERE f.forest_no::text = i.forest_no::text
GROUP BY f.forest_no;

alter table forest_road
    owner to postgres;

