create materialized view duties_mv as
SELECT s.maintainer,
       count(s.maintainer) AS total_num_of_sensors_per_maintainer
FROM worker w,
     sensor s
WHERE s.maintainer::text = w.ssn::text
GROUP BY s.maintainer;

alter materialized view duties_mv owner to postgres;

